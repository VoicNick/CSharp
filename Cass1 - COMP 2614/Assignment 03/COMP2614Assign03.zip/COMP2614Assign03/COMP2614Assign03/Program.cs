﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//adding namespace for StreamReader
using System.IO;

// Assignment 3 for the Comp2614 class, Summer 2016 term
// Author: Voicu Chirtes
// Version: May 31, 2016

namespace COMP2614Assign03
{
    class Program
    {
        //
        //
        /// <summary>
        /// Entry point for the progam
        /// </summary>
        /// <param name="args">The full path to the source data file</param>
        /// <returns> return codes: 0 = success; 1 = invalid program call, missing parameter; 
        /// 2 = file not found; </returns>
        static int Main(string[] args)
        {
            //will store the path to the data file
            string path;
            // will read from the file
            StreamReader streamReader = null;

            // verify correct program usage. Must have the data file name 
            // as an argument. E.g. COMP2614Assign03 data.txt
            if (args.Length > 0)
            {
                path = args[0];
            }
            else
            {
                Console.WriteLine("Error: Missing parameter: data file name.");
                Console.WriteLine("Correct program usage: COMP2614Assign03 <full path to data file>");
                Console.WriteLine("e.g. COMP2614Assign03 data.txt");
                return 1;
            }

            //try to open the source data file and,
            //if successfull execute main program logic
            try
            {
                // in order to check the file,we could do the below, 
                // however in this case I've opted to let the exception handle it
                ////verify if file exist
                //if(!File.Exists(path))
                //{
                //    Console.WriteLine("Error: File not found at {0}", path);
                //    return 2;
                //}

                //trying to open the file, this might throw an exception
                streamReader = new StreamReader(path);

                //a list of Invoice objects
                InvoiceCollection invoiceCollection = new InvoiceCollection();

                //looping throught the file, while there is content
                while (streamReader.Peek() > 0)
                {
                    //processing the data based on descrition of the data file

                    //a line in the file, including header and invoice detail items
                    string currentLine;
                    currentLine = streamReader.ReadLine();
                    string[] dataOnCurrentLine = currentLine.Split('|');

                    //_to_do validation on the split method and result

                    //reading the header of the invoice on the curerent line
                    string[] invoiceHeaderData = dataOnCurrentLine[0].Split(':');

                    //creating a DateTime object from the string YYYY/MM/DD
                    string[] currentInvoiceStringDate = invoiceHeaderData[1].Split('/');
                    DateTime currentInvoiceDateTimeObject = new DateTime(
                        Int32.Parse(currentInvoiceStringDate[0]),
                        Int32.Parse(currentInvoiceStringDate[1]),
                        Int32.Parse(currentInvoiceStringDate[2]));

                    //dealing with the discount terms percentage and date
                    int allTermsInInt = Int32.Parse(invoiceHeaderData[2]);
                    //making an int to get the reminder of division to 100 and 
                    //then dividing againt with 100.0 to get a double, for easy percetage calculations 
                    //( e. g. 3%  is represented as 0.03)
                    double currentInvoiceDiscountPercentage = (allTermsInInt / 100) / 100.0;
                    int currentInvoiceDiscountNoOfDays = allTermsInInt % 100;

                    //reading the additional lines on the invoice form the current line

                    //this will be stored on a collection list of InvoiceDetailLine objects
                    InvoiceDetailLineCollection currentDetailLine = new InvoiceDetailLineCollection();

                    //we start at the secound element at index 1, to skip the header processesd before
                    for (int i = 1; i < dataOnCurrentLine.Length; i++)
                    {
                        string[] invoiceAdditionalLine = dataOnCurrentLine[i].Split(':');

                        InvoiceDetailLine.taxablePST temp;
                        if ((invoiceAdditionalLine[4]).CompareTo("Y") == 0)
                        {
                            temp = InvoiceDetailLine.taxablePST.Y;
                        }
                        else
                        {
                            temp = InvoiceDetailLine.taxablePST.N;
                        }

                        //adding a new InvoiceDetailLine object to the list
                        //to do this can be improved to do some validation
                        currentDetailLine.Add(new InvoiceDetailLine
                        {
                            Quantity = Int32.Parse(invoiceAdditionalLine[0]),
                            Sku = invoiceAdditionalLine[1],
                            Description = invoiceAdditionalLine[2],
                            PriceInUSD = Decimal.Parse(invoiceAdditionalLine[3]),
                            TaxablePST = temp
                        });
                    }

                    //create an invoice object and add it to the list
                    invoiceCollection.Add(new Invoice
                    {
                        InvoiceNumber = invoiceHeaderData[0],
                        InvoiceDate = currentInvoiceDateTimeObject,
                        InvoiceDiscountPercentage = currentInvoiceDiscountPercentage,
                        InvoiceDiscountNoOfDays = currentInvoiceDiscountNoOfDays,
                        InvoiceDetailCollection = currentDetailLine
                    });

                }//end of the loop reading the file

                //printing all the invoices in the list
                invoiceCollection.PrintInvoiceCollection();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error opening the file{0}\n{1}", path, ex.Message);
            }

            finally // if there was an error we want to make sure to close the stream
            {
                if (streamReader != null)
                {
                    streamReader.Close();
                }
            }
            return 0;
        }
    }
}
