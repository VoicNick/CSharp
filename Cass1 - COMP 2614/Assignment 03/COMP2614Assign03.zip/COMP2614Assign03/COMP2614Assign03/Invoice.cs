﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP2614Assign03
{
    /// <summary>
    /// The abstract representation of an invoice
    /// </summary>
    class Invoice
    {
        //GST and PST tax percentage const
        private double GST_PERCENTAGE = 0.05D; // GST is 5%
        private double PST_PERCENTAGE = 0.07D; // PST is 7%

        /// <summary>
        /// The invoice number
        /// </summary>
        public string InvoiceNumber {get; set;}

        /// <summary>
        /// The date of the invoice
        /// </summary>
        public DateTime InvoiceDate {get; set; }

        /// <summary>
        /// The discount percentage, if the invoice is paid by by 
        /// the number of days InvoiceDiscountNoOfDays
        /// </summary>
        public double InvoiceDiscountPercentage { get; set; }

        /// <summary>
        /// The number of days until a discount is available
        /// </summary>
        public int InvoiceDiscountNoOfDays { get; set; }

        /// <summary>
        /// A collection of all the product lines on an invoice 
        /// this is modeled as a list of a InvoiceDetailLine objects
        /// </summary>
        public InvoiceDetailLineCollection InvoiceDetailCollection { get; set; }

        /// <summary>
        /// The date until there is a discout available
        /// </summary>
        public DateTime DiscountDate
        {
            get
            {
                return InvoiceDate.AddDays(InvoiceDiscountNoOfDays);
            }
        }

        /// <summary>
        /// The subtotal in USD excluding the taxes
        /// </summary>
        public decimal InvoiceSubtotalInUSD
        {
            get 
            {
                return InvoiceDetailCollection.CollectionSubtotalInUSD;
            }
        }

        /// <summary>
        /// The total GST tax amount in USD for the invoice
        /// Note: All invoices have a GST
        /// </summary>
        public decimal InvoiceGSTInUSD
        {
            get
            {
                return InvoiceSubtotalInUSD * (decimal)GST_PERCENTAGE;
            }
        }

        /// <summary>
        /// This is the total PST tax amount in USD for the invoice
        /// Note: Not all invoices have a PST, this can be 0
        /// </summary>
        public decimal InvoicePSTInUSD
        {
            get
            {
                return InvoiceDetailCollection.CollectionPSTTaxableSubtotalInUSD * (decimal)PST_PERCENTAGE;
            }
        }

        /// <summary>
        /// Total invoice amount in USD including taxes
        /// </summary>
        public decimal InvoiceTotalInUSD
        {
            get
            {
                return InvoiceSubtotalInUSD + InvoiceGSTInUSD + InvoicePSTInUSD;
            }
        }

        /// <summary>
        /// Discount amount in USD if paid by discount date
        /// </summary>
        public decimal InvoiceDiscountInUSD
        {
            get
            {
                return (decimal)InvoiceDiscountPercentage * InvoiceTotalInUSD;
            }
        }

        //This could be improved and moved into another class.
        /// <summary>
        /// Outputs the current invoice to the screen in a formatted way
        /// </summary>
        public void PrintInvoice()
        {
            Console.WriteLine("{0,-16}{1}", "Invoice Number:", InvoiceNumber);
            Console.WriteLine("{0,-16}{1}", "Invoice Date:",InvoiceDate.ToString("MMM d, yyyy"));
            Console.WriteLine("{0,-16}{1}", "Discount Date:", DiscountDate.ToString("MMM d, yyyy"));
            Console.WriteLine("{0,-16}{1}% {2} days ADI", "Terms:", InvoiceDiscountPercentage * 100, InvoiceDiscountNoOfDays);
            InvoiceDetailCollection.PrintInvoiceDetailLineCollection();
            Console.WriteLine("{0,-16}{1,-25}{2,20:N2}", "", "Subtotal:", InvoiceSubtotalInUSD);
            Console.WriteLine("{0,-16}{1,-25}{2,20:N2}", "", "GST:", InvoiceGSTInUSD); 
            if(InvoicePSTInUSD >0)
            {
                Console.WriteLine("{0,-16}{1,-25}{2,20:N2}", "", "PST:", InvoicePSTInUSD); 
            }
            Console.WriteLine(new string('-', 61));
            Console.WriteLine("{0,-16}{1,-25}{2,20:N2}", "", "Total:", InvoiceTotalInUSD);
            Console.WriteLine("\n{0,-16}{1,-25}{2,20:N2}", "", "Discount:", InvoiceDiscountInUSD);
            Console.WriteLine("\n\n");
        }
    }
}
