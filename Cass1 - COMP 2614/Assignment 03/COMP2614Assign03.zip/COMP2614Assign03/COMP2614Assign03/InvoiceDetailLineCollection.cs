﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP2614Assign03
{
    /// <summary>
    /// A class to model a colection of InvoiceDetailLine objects
    /// Each invoice would incoude a member of type of this class
    /// </summary>
    class InvoiceDetailLineCollection : List<InvoiceDetailLine>
    {
        /// <summary>
        /// Subtotal in USD for all the products in the collection
        /// excluding tax
        /// </summary>
        public decimal CollectionSubtotalInUSD
        {
            get
            {
                decimal collectionSubtotalInUSD = 0;
                foreach (InvoiceDetailLine currentDetailLine in this)
                {
                    collectionSubtotalInUSD += currentDetailLine.ProductTotalPriceInUSD;
                }
                return collectionSubtotalInUSD;
            }
        }

        /// <summary>
        /// Subtotal in USD for the PST taxable products in this collection
        /// </summary>
        public decimal CollectionPSTTaxableSubtotalInUSD
        {
            get
            {
                decimal collectionPSTTaxableSubtotalInUSD = 0;
                InvoiceDetailLine.taxablePST taxablePST = InvoiceDetailLine.taxablePST.Y;
                foreach (InvoiceDetailLine currentDetailLine in this)
                {
                    if (currentDetailLine.TaxablePST == taxablePST)
                    {
                        collectionPSTTaxableSubtotalInUSD += currentDetailLine.ProductTotalPriceInUSD;
                    }
                }
                return collectionPSTTaxableSubtotalInUSD;
            }
        }


        /// <summary>
        /// Print the whole Invoice Detail collection to the screen
        /// </summary>
        public void PrintInvoiceDetailLineCollection()
        {
            Console.WriteLine(new string('-', 61));
            Console.WriteLine("{0,3} {1,-11} {2,-20} {3,10} PST {4,9}",
                "Qty", "SKU", "Description", "Price", "Ext");
            Console.WriteLine(new string('-', 61));
            foreach(InvoiceDetailLine currentDetailLine in this)
            {
                Console.WriteLine("{0,3} {1,-11} {2,-20} {3,10:N2}  {4}  {5,9:N2}",
                    currentDetailLine.Quantity, currentDetailLine.Sku, currentDetailLine.Description,
                    currentDetailLine.PriceInUSD, currentDetailLine.TaxablePST, currentDetailLine.ProductTotalPriceInUSD);
            }
            Console.WriteLine(new string('-', 61));
        }
    }
}
