﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP2614Assign03
{
    /// <summary>
    /// A class to model a product line in an invoice.
    /// </summary>
    class InvoiceDetailLine
    {
        /// <summary>
        /// The quantity of the product on this line
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// The SKU of the product on this line
        /// </summary>
        public string Sku { get; set; }

        /// <summary>
        /// The description of the product on this line
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// The price in USD of the product on this line
        /// </summary>
        public decimal PriceInUSD { get; set; }

        /// <summary>
        /// An enmum to represent if the of the product on this line
        /// is PST taxable
        /// </summary>
        public enum taxablePST {Y, N}

        /// <summary>
        /// This determines it a PST tax is applied to 
        /// the product on this line
        /// </summary>
        public taxablePST TaxablePST { get; set; }

        /// <summary>
        /// The total price in USD of the product on this line
        /// excluding tax
        /// </summary>
        public decimal ProductTotalPriceInUSD 
        {
            get
            {
                return PriceInUSD * Quantity;
            }
        }
    }
}
